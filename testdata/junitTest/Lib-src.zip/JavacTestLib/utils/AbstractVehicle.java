package utils;

public abstract class AbstractVehicle {
    
    private String name;
    
    protected AbstractVehicle(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }

}

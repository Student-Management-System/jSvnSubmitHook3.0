import cars.Car;

public class Main {

    public static void main(String[] args) {
        Car c = new Car("Mazda");
        System.out.println(c.getName());
    }
    
}

package de.uni_hildesheim.sse.test;

import org.junit.Test;

import de.uni_hildesheim.sse.javaSvnHooks.tests.junit.testSuiteInterface.TestFailure;
import de.uni_hildesheim.sse.javaSvnHooks.tests.junit.testSuiteInterface.WrappedClass;
import de.uni_hildesheim.sse.test.utils.ProjectUtilities;

/**
 * Allgemeingueltige Testfaelle, die immer genutzt werden koennen.
 * 
 * @author El-Sharkawy
 *
 */
public class GeneralTests {

    /**
     * Testet ob ein Kommentar in der ersten Zeile existiert. 
     * Studenten sollen Hausaufgabe und Teammitglieder als Kommentar in die erste Zeile schreiben.
     */
    @Test
    public void testKommentarInErsterZeile() {
        for (WrappedClass javaClass : JavaTestSuite.getClassRegistry().getAllWrappedClasses()) {
            if (null != javaClass.getContent()) {
                String srcFile = javaClass.getFileName();
                String quellCode = javaClass.getContent();
                if (!quellCode.startsWith("//") && !quellCode.startsWith("/*")) {
                    JavaTestSuite.getTestResult().addTestFailure(new TestFailure(
                            "Angabe der Autoren fehlt.", true, srcFile, 1));
                }
            }
        }
    }

    /**
     * Testet, dass die abgegebenen Projekte exakt eine Main-Methode enthalten.
     */
    @Test
    public void testOnlyOneMain() {
        ProjectUtilities.assertMaxMainMethods(1);
    }
}

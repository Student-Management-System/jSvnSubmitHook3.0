package de.uni_hildesheim.sse.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import de.uni_hildesheim.sse.test.suite.AbstractJavaTestSuite;

/**
 * Hauptklasse, die von jSVNSubmitHook geladen wird. Diese Klasse darf nicht
 * umbeannt oder verschoben werden.
 * 
 * @author Adam Krafczyk
 */
@RunWith(Suite.class)
@SuiteClasses({
    // Hier die Testfälle eintragen.
    GeneralTests.class, OOStructureTests.class
})
public class JavaTestSuite extends AbstractJavaTestSuite {

    // No change here - use TestDebugHarness.
    
}

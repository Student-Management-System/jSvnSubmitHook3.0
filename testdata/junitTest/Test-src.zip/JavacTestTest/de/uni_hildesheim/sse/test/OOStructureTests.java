package de.uni_hildesheim.sse.test;

import org.junit.BeforeClass;
import org.junit.Test;

import de.uni_hildesheim.sse.test.utils.oo.OOAnalyzer;
import de.uni_hildesheim.sse.test.utils.oo.OOAnalyzerUtils;
import de.uni_hildesheim.sse.test.utils.oo.Visibility;
import org.junit.Assert;

/**
 * Testet die geforderte OO Struktur.
 * @author Christian Ackermann
 *
 */
public class OOStructureTests {
    
    private static final String PACKAGE= "cars";
    
    /**
     * Setzt die benutzerdefinierten Klassen um sie ueberall verwenden zu koennen.
     */
    @BeforeClass
    public static void setUpBeforeClass() {
    }

    /**
     * Testet die korrekte Struktur der Klasse <tt>Car</tt>.
     */
    @Test
    public void testCar() {
        OOAnalyzer aVehicle = new OOAnalyzer("utils", "AbstractVehicle");
        aVehicle.classExists();
        // Klasse
        OOAnalyzer analyzer = new OOAnalyzer(PACKAGE, "Car");
        boolean classExists = analyzer.classExists();
        if (classExists) {
            Assert.assertNotNull(OOAnalyzerUtils.getUserDefinedType("utils", "AbstractVehicle"));
            Assert.assertTrue(analyzer.extendsFrom("utils", "AbstractVehicle"));
        }
        analyzer.methodExists("main", Visibility.PUBLIC, null, true, null, String[].class);
    }
    
    /**
     * Testet die korrekte Struktur der Klasse <tt>Main</tt>.
     */
    @Test
    public void testMain() {
        // Klasse
        OOAnalyzer analyzer = new OOAnalyzer(null, "Main");
        analyzer.classExists();
        analyzer.methodExists("main", Visibility.PUBLIC, null, true, null, String[].class);
    }

}

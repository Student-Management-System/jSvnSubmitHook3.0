/**
 * Test suite and general test class.
 * @author El-Sharkawy
 *
 */
package de.uni_hildesheim.sse.test;